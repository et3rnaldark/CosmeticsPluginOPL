package com.solecloth7.cosmeticsPluginOPL.command.sub.item

import com.solecloth7.cosmeticsPluginOPL.command.AdminSubcommand
import com.solecloth7.cosmeticsPluginOPL.cosmetics.CosmeticManager
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player

class ItemModifySubcommand : AdminSubcommand {
    override val name = "modify"
    override val description = "Modify a cosmetic item"

    override fun execute(sender: CommandSender, args: List<String>) {
        if (sender !is Player) {
            sender.sendMessage("§cOnly players can use this.")
            return
        }
        if (args.size < 4 || args[0].lowercase() != "chat_color" || args[1].lowercase() != "paint") {
            sender.sendMessage("§cUsage: /a item modify chat_color paint #HEX1,#HEX2,... Name Here[,bold]")
            return
        }

        // --- 1. Extract hex codes from the first arg after 'paint' ---
        val rawHexes = args[2].split(",").map { it.trim() }
            .filter { it.isNotEmpty() && it.matches(Regex("^#?[A-Fa-f0-9]{6}$")) }
            .map { if (it.startsWith("#")) it else "#$it" }
        if (rawHexes.isEmpty()) {
            sender.sendMessage("§cPlease specify at least one valid 6-digit hex code!")
            return
        }

        // --- 2. Join the rest as one string (the name, possibly ending with ,bold) ---
        val nameWithPossibleBold = args.subList(3, args.size).joinToString(" ")

        // --- 3. Split out ',bold' if present ---
        val (finalName, bold) = if (nameWithPossibleBold.trim().endsWith(",bold", ignoreCase = true)) {
            nameWithPossibleBold.trim().removeSuffix(",bold").removeSuffix(",BOLD").trim() to true
        } else {
            nameWithPossibleBold.trim() to false
        }

        if (finalName.isEmpty()) {
            sender.sendMessage("§cPlease specify a name for your chat color cosmetic!")
            return
        }

        val cosmetic = CosmeticManager.getMostRecentChatColorCosmetic(sender)
        if (cosmetic == null) {
            sender.sendMessage("§cNo Chat Color cosmetic found in your backpack!")
            return
        }
        cosmetic.hexColors = rawHexes
        cosmetic.text = finalName
        cosmetic.bold = bold

        CosmeticManager.updateCosmetic(sender, cosmetic)
        sender.sendMessage("§aUpdated your chat color cosmetic to preview: §r${cosmetic.displayName}")
    }


    override fun tabComplete(sender: CommandSender, args: List<String>): List<String> {
        if (args.size == 1) return listOf("chat_color").filter { it.startsWith(args[0]) }
        if (args.size == 2) return listOf("paint").filter { it.startsWith(args[1]) }
        return emptyList()
    }
}
