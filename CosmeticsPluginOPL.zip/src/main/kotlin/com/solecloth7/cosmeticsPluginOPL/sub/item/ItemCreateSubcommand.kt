package com.solecloth7.cosmeticsPluginOPL.command.sub.item

import com.solecloth7.cosmeticsPluginOPL.command.AdminSubcommand
import com.solecloth7.cosmeticsPluginOPL.cosmetics.types.ChatColorCosmetic
import com.solecloth7.cosmeticsPluginOPL.cosmetics.CosmeticManager
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player

class ItemCreateSubcommand : AdminSubcommand {
    override val name = "create"
    override val description = "Create a cosmetic item"

    override fun execute(sender: CommandSender, args: List<String>) {
        if (sender !is Player) {
            sender.sendMessage("§cOnly players can use this.")
            return
        }
        if (args.isEmpty() || args[0].lowercase() != "chat_color") {
            sender.sendMessage("§cUsage: /a item create chat_color")
            return
        }
        val cosmetic = ChatColorCosmetic.default()
        CosmeticManager.giveCosmetic(sender, cosmetic)
        sender.sendMessage("§aAdded default chat color cosmetic to your backpack!")
    }

    override fun tabComplete(sender: CommandSender, args: List<String>): List<String> {
        return if (args.size == 1) listOf("chat_color").filter { it.startsWith(args[0]) } else emptyList()
    }
}
