package com.solecloth7.cosmeticsPluginOPL.cosmetics.types

import com.solecloth7.cosmeticsPluginOPL.util.ColorUtil
import org.bukkit.inventory.ItemStack
import org.bukkit.Material

data class ChatColorCosmetic(
    var hexColors: List<String> = listOf("#FFFFFF"),
    var text: String = "White",
    var bold: Boolean = false,
    val customModelData: Int = 40500
) {
    val displayName: String
        get() = "§7Basic Chat Color: " + ColorUtil.gradientName(text, hexColors, bold)

    fun toItem(): ItemStack {
        val item = ItemStack(Material.PAPER)
        val meta = item.itemMeta!!
        meta.setCustomModelData(customModelData)
        meta.setDisplayName(displayName)
        meta.lore = listOf("§8Click to equip!")
        item.itemMeta = meta
        return item
    }

    companion object {
        fun default() = ChatColorCosmetic(
            hexColors = listOf("#FFFFFF"),
            text = "White",
            bold = false
        )
    }
}
