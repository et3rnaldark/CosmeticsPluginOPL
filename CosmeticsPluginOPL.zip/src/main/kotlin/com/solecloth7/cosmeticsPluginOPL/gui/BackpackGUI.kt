package com.solecloth7.cosmeticsPluginOPL.gui

import com.solecloth7.cosmeticsPluginOPL.cosmetics.CosmeticManager
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack

object BackpackGUI {
    private const val SIZE = 36
    private const val TITLE = "Cosmetic Backpack"

    fun open(player: Player) {
        val inv: Inventory = Bukkit.createInventory(null, SIZE, TITLE)
        val cosmetics = CosmeticManager.getCosmetics(player)
        for ((i, cosmetic) in cosmetics.withIndex()) {
            if (i < SIZE) {
                inv.setItem(i, cosmetic.toItem())
            }
        }
        for (i in cosmetics.size until SIZE) {
            inv.setItem(i, ItemStack(Material.GRAY_STAINED_GLASS_PANE).apply {
                val meta = itemMeta
                meta?.setDisplayName("§7Cosmetic Slot")
                itemMeta = meta
            })
        }
        player.openInventory(inv)
    }

    fun open(admin: Player, target: Player) {
        val inv: Inventory = Bukkit.createInventory(
            null,
            SIZE,
            "Viewing Backpack: ${target.name}"
        )
        val cosmetics = CosmeticManager.getCosmetics(target)
        for ((i, cosmetic) in cosmetics.withIndex()) {
            if (i < SIZE) {
                inv.setItem(i, cosmetic.toItem())
            }
        }
        for (i in cosmetics.size until SIZE) {
            inv.setItem(i, ItemStack(Material.GRAY_STAINED_GLASS_PANE).apply {
                val meta = itemMeta
                meta?.setDisplayName("§7Cosmetic Slot")
                itemMeta = meta
            })
        }
        admin.openInventory(inv)
    }

    fun handleClick(player: Player, event: InventoryClickEvent) {
        val clicked = event.currentItem ?: return
        if (clicked.type == Material.PAPER) {
            val cosmetics = CosmeticManager.getCosmetics(player)
            val cosmetic = cosmetics.getOrNull(event.slot)
            if (cosmetic != null) {
                event.isCancelled = true
                EquipGUI.open(player, cosmetic)
            }
        } else {
            event.isCancelled = true
        }
    }

    fun handleAdminClick(admin: Player, target: Player, event: InventoryClickEvent) {
        event.isCancelled = true // Always prevent edits in admin view!
        val clicked = event.currentItem ?: return
        if (clicked.type == Material.PAPER) {
            val cosmetics = CosmeticManager.getCosmetics(target)
            val cosmetic = cosmetics.getOrNull(event.slot)
            if (cosmetic != null) {
                // Register the selection
                AdminSelectionManager.select(admin, target, event.slot)
                admin.closeInventory()
                admin.sendMessage("§aSuccessfully selected '${cosmetic.text}' from ${target.name}'s backpack!")
            }
        }
    }

}
