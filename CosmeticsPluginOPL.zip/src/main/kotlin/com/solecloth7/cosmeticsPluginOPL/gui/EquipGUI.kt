package com.solecloth7.cosmeticsPluginOPL.gui

import com.solecloth7.cosmeticsPluginOPL.cosmetics.CosmeticManager
import com.solecloth7.cosmeticsPluginOPL.cosmetics.types.ChatColorCosmetic
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack

object EquipGUI {
    private const val SIZE = 9
    private const val TITLE = "Equip Chat Color"

    fun open(player: Player, cosmetic: ChatColorCosmetic) {
        val inv: Inventory = Bukkit.createInventory(null, SIZE, TITLE)
        inv.setItem(4, cosmetic.toItem())
        val equip = ItemStack(Material.LIME_STAINED_GLASS_PANE).apply {
            val meta = itemMeta
            meta?.setDisplayName("§a§lEquip")
            itemMeta = meta
        }
        inv.setItem(6, equip)
        val cancel = ItemStack(Material.RED_STAINED_GLASS_PANE).apply {
            val meta = itemMeta
            meta?.setDisplayName("§cCancel")
            itemMeta = meta
        }
        inv.setItem(2, cancel)
        player.openInventory(inv)
    }

    fun handleClick(player: Player, event: InventoryClickEvent, cosmetic: ChatColorCosmetic) {
        when (event.rawSlot) {
            6 -> {
                CosmeticManager.equipCosmetic(player, cosmetic)
                player.sendMessage("§aYou equipped: §r${cosmetic.displayName}")
                player.closeInventory()
            }
            2 -> player.closeInventory()
            else -> event.isCancelled = true
        }
    }

}
