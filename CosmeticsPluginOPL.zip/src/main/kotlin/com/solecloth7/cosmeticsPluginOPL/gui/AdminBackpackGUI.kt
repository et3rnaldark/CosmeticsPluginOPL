package com.solecloth7.cosmeticsPluginOPL.gui

import com.solecloth7.cosmeticsPluginOPL.cosmetics.CosmeticManager
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.inventory.ItemStack
import java.util.UUID

object AdminBackpackGUI {
    private const val SIZE = 36
    private const val TITLE = "Viewing Backpack"
    // In BackpackGUI
    fun open(admin: Player, target: Player) {
        val inv = Bukkit.createInventory(null, SIZE, "§b${target.name}'s Backpack")
        val cosmetics = CosmeticManager.getCosmetics(target)
        for ((i, cosmetic) in cosmetics.withIndex()) {
            if (i < SIZE) {
                inv.setItem(i, cosmetic.toItem())
            }
        }
        for (i in cosmetics.size until SIZE) {
            inv.setItem(i, ItemStack(Material.GRAY_STAINED_GLASS_PANE).apply {
                val meta = itemMeta
                meta?.setDisplayName("§7Cosmetic Slot")
                itemMeta = meta
            })
        }
        AdminSelectView.setViewing(admin, target)
        admin.openInventory(inv)
    }


    object AdminBackpackSession {
        val currentlyViewing = mutableMapOf<UUID, UUID>()
    }

    fun handleClick(admin: Player, event: InventoryClickEvent) {
        event.isCancelled = true
        val targetId = AdminBackpackSession.currentlyViewing[admin.uniqueId] ?: return
        val target = Bukkit.getPlayer(targetId) ?: return
        val cosmetics = CosmeticManager.getCosmetics(target)
        val cosmetic = cosmetics.getOrNull(event.slot) ?: return
        // Only open the modify GUI for this cosmetic, nothing else
        AdminCosmeticModifyGUI.open(admin, target, cosmetic)
    }
}
