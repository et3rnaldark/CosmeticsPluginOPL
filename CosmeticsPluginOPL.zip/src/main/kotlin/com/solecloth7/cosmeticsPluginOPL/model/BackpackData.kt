package com.solecloth7.cosmeticsPluginOPL.model

import com.solecloth7.cosmeticsPluginOPL.cosmetics.types.ChatColorCosmetic

data class BackpackData(
    val chatColorCosmetics: List<ChatColorCosmetic> = emptyList(),
    val equippedChatColorIndex: Int? = null
)
