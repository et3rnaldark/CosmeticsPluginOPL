package com.solecloth7.cosmeticsPluginOPL.command

import com.solecloth7.cosmeticsPluginOPL.gui.BackpackGUI
import org.bukkit.command.Command
import org.bukkit.command.CommandExecutor
import org.bukkit.command.CommandSender
import org.bukkit.command.TabExecutor
import org.bukkit.entity.Player

import org.bukkit.command.TabCompleter

class BackpackCommand : CommandExecutor, TabCompleter {
    override fun onCommand(
        sender: CommandSender,
        command: Command,
        label: String,
        args: Array<out String>
    ): Boolean {
        if (sender is Player) {
            BackpackGUI.open(sender)
        } else {
            sender.sendMessage("Only players can use this command.")
        }
        return true
    }

    override fun onTabComplete(
        sender: CommandSender,
        command: Command,
        alias: String,
        args: Array<out String>
    ): List<String>? {
        return emptyList()
    }
}
