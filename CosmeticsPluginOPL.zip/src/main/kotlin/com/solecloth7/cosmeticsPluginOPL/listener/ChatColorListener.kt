package com.solecloth7.cosmeticsPluginOPL.listener

import com.solecloth7.cosmeticsPluginOPL.cosmetics.CosmeticManager
import com.solecloth7.cosmeticsPluginOPL.util.ColorUtil
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.AsyncPlayerChatEvent

class ChatColorListener : Listener {
    @EventHandler
    fun onChat(e: AsyncPlayerChatEvent) {
        val player = e.player
        val cosmetic = CosmeticManager.getEquippedCosmetic(player)
        if (cosmetic != null) {
            val gradientMessage = ColorUtil.gradientName(e.message, cosmetic.hexColors, cosmetic.bold)
            e.message = gradientMessage
        }
    }
}
