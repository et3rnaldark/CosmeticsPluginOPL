package com.solecloth7.cosmeticsPluginOPL.listener

import com.solecloth7.cosmeticsPluginOPL.gui.BackpackGUI
import com.solecloth7.cosmeticsPluginOPL.gui.EquipGUI
import com.solecloth7.cosmeticsPluginOPL.cosmetics.CosmeticManager
import com.solecloth7.cosmeticsPluginOPL.gui.AdminBackpackGUI
import com.solecloth7.cosmeticsPluginOPL.gui.AdminCosmeticModifyGUI
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.inventory.InventoryCloseEvent

class BackpackListener : Listener {
    @EventHandler
    fun onClick(e: InventoryClickEvent) {
        val player = e.whoClicked as? org.bukkit.entity.Player ?: return
        val title = e.view.title
        when {
            title == "Cosmetic Backpack" -> BackpackGUI.handleClick(player, e)
            title == "Equip Chat Color" -> {
                val cosmetics = CosmeticManager.getCosmetics(player)
                val cosmetic = cosmetics.find { it.toItem().isSimilar(e.inventory.getItem(4)) }
                if (cosmetic != null) {
                    EquipGUI.handleClick(player, e, cosmetic)
                } else {
                    e.isCancelled = true
                }
            }
            title.startsWith("Viewing Backpack") -> {
                AdminBackpackGUI.handleClick(player, e)
            }
            title == "Modify Cosmetic" -> {
                AdminCosmeticModifyGUI.handleClick(player, e)
            }
        }
    }

    @EventHandler
    fun onDrag(e: org.bukkit.event.inventory.InventoryDragEvent) {
        val title = e.view.title
        if (title == "Cosmetic Backpack" || title == "Equip Chat Color") {
            e.isCancelled = true
        }
    }
}
