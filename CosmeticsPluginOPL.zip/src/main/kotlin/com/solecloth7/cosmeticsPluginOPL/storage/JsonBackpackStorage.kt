package com.solecloth7.cosmeticsPluginOPL.storage

import com.google.gson.GsonBuilder
import com.solecloth7.cosmeticsPluginOPL.model.BackpackData
import com.solecloth7.cosmeticsPluginOPL.cosmetics.types.ChatColorCosmetic
import org.bukkit.entity.Player
import java.io.File

object JsonBackpackStorage {
    private val gson = GsonBuilder().setPrettyPrinting().create()
    lateinit var dataFolder: File


    fun getFileFor(player: Player): File = File(dataFolder, "${player.uniqueId}.json")

    fun saveBackpack(player: Player, cosmetics: List<ChatColorCosmetic>, equipped: Int?) {
        val data = BackpackData(cosmetics, equipped)
        val file = getFileFor(player)
        file.parentFile.mkdirs()
        file.writeText(gson.toJson(data))
    }

    fun loadBackpack(player: Player): BackpackData {
        val file = getFileFor(player)
        if (!file.exists()) return BackpackData()
        return try {
            gson.fromJson(file.readText(), BackpackData::class.java) ?: BackpackData()
        } catch (ex: Exception) {
            ex.printStackTrace()
            BackpackData()
        }

        println("Backpack file: " + getFileFor(player).absolutePath)

    }
}
