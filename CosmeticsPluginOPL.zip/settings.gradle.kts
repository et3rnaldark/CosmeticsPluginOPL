rootProject.name = "CosmeticsPluginOPL"
